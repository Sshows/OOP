package com.company;

public class Main {
    private int shift; // Сдвиг шифра

    public Main(int shift) {
        this.shift = shift % 26;  
    }

    public String encrypt(String text) {
        return transform(text, shift);
    }

    public String decrypt(String text) {
        return transform(text, 26 - shift);
    }

    private String transform(String text, int shift) {
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                c = (char) ((c - base + shift) % 26 + base);
            }
            result.append(c);
        }
        return result.toString();
    }

    public static void main(String[] args) {
        Main cipher = new Main(4);
        String originalText = "HELLO";

        String encryptedText = cipher.encrypt(originalText);
        System.out.println("Шифрованный текст: " + encryptedText);

        String decryptedText = cipher.decrypt(encryptedText);
        System.out.println("Расшифрованный текст: " + decryptedText);
    }
}
